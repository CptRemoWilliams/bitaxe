# bitaxe
BitAxe Monitor
Step 1: Download both files (monitor.html and wallpaper.gif).
Add the favicon.ico file if you want a browser Bitcoin Icon on your tab.
Step 2: Place all files in the same folder together.
Step 3: Edit the monitor.html file, look specifically for the ip addresses (near the bottom section of the code) that say 192.168.162.250 and modify each of them to specifically point to each of your Bitaxe ip addresses. 
(Note ** You can use any webpage on the internet instead of an IP address, but not every webpage is designed to run in an in-line window. Example is having an IP camera if you wanted.)
You can use any wallpaper you want then the one I chose here, just make sure it's called wallpaper.gif, or alter the code in monitor.html to point to your specific choice of wallpaper.
Enjoy!
